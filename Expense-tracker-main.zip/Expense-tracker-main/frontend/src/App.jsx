import { useState, useEffect } from "react";
import ExpenseForm from "./components/ExpenseForm";
import ExpenseList from "./components/ExpenseList";
import FilterBar from "./components/FilterBar";
import { getExpenses, getCategories, addExpense, updateExpense, deleteExpense } from "./api";
import "./App.css";

function App() {
  const [expenses, setExpenses] = useState([]);
  const [categories, setCategories] = useState([]);
  const [editingExpense, setEditingExpense] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [filters, setFilters] = useState({ category_id: "", from_date: "", to_date: "" });
  const [message, setMessage] = useState("");
  const [totalAmount, setTotalAmount] = useState(0);

  useEffect(() => {
    loadCategories();
    loadExpenses();
  }, []);

  // Reload when filters change
  useEffect(() => {
    loadExpenses();
  }, [filters]);

  async function loadCategories() {
    try {
      const data = await getCategories();
      setCategories(data);
    } catch (err) {
      console.error(err.message);
    }
  }

  async function loadExpenses() {
    try {
      // Remove empty filter keys before sending
      const activeFilters = Object.fromEntries(
        Object.entries(filters).filter(([_, v]) => v !== "")
      );
      const data = await getExpenses(activeFilters);
      setExpenses(data);
      const total = data.reduce((sum, e) => sum + Number(e.AMOUNT), 0);
      setTotalAmount(total.toFixed(2));
    } catch (err) {
      console.error(err.message);
    }
  }

  async function handleAddOrUpdate(formData) {
    try {
      if (editingExpense) {
        await updateExpense(editingExpense.ID, formData);
        showMessage("Expense updated!");
      } else {
        await addExpense(formData);
        showMessage("Expense added!");
      }
      setEditingExpense(null);
      setShowForm(false);
      loadExpenses();
    } catch (err) {
      showMessage("Error: " + err.message);
    }
  }

  async function handleDelete(id) {
    if (!window.confirm("Delete this expense?")) return;
    try {
      await deleteExpense(id);
      showMessage("Expense deleted!");
      loadExpenses();
    } catch (err) {
      showMessage("Error: " + err.message);
    }
  }

  function handleEdit(expense) {
    setEditingExpense(expense);
    setShowForm(true);
    window.scrollTo(0, 0);
  }

  function handleCancel() {
    setEditingExpense(null);
    setShowForm(false);
  }

  function handleFilterReset() {
    setFilters({ category_id: "", from_date: "", to_date: "" });
  }

  function showMessage(msg) {
    setMessage(msg);
    setTimeout(() => setMessage(""), 3000);
  }

  return (
    <div className="app">
      <header>
        <h1>Expense Tracker</h1>
        <p>Track your daily expenses easily</p>
      </header>

      <main>
        {message && <div className="toast">{message}</div>}

        {/* Add / Edit Form */}
        {showForm ? (
          <ExpenseForm
            categories={categories}
            onSubmit={handleAddOrUpdate}
            existingData={editingExpense}
            onCancel={handleCancel}
          />
        ) : (
          <button className="btn-add" onClick={() => setShowForm(true)}>
            + Add New Expense
          </button>
        )}

        {/* Filter Bar */}
        <FilterBar
          categories={categories}
          filters={filters}
          onChange={setFilters}
          onReset={handleFilterReset}
        />

        {/* Summary */}
        <div className="summary">
          <span>{expenses.length} expense(s) found</span>
          <span>Total: ₹{totalAmount}</span>
        </div>

        {/* Expense List */}
        <ExpenseList
          expenses={expenses}
          onEdit={handleEdit}
          onDelete={handleDelete}
        />
      </main>
    </div>
  );
}

export default App;
