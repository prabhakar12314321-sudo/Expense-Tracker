function FilterBar({ categories, filters, onChange, onReset }) {
  function handleChange(e) {
    onChange({ ...filters, [e.target.name]: e.target.value });
  }

  return (
    <div className="filter-bar">
      <h3>Filter Expenses</h3>
      <div className="filter-row">
        <div className="form-group">
          <label>Category</label>
          <select name="category_id" value={filters.category_id} onChange={handleChange}>
            <option value="">All</option>
            {categories.map((cat) => (
              <option key={cat.ID} value={cat.ID}>
                {cat.NAME}
              </option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label>From Date</label>
          <input
            type="date"
            name="from_date"
            value={filters.from_date}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label>To Date</label>
          <input
            type="date"
            name="to_date"
            value={filters.to_date}
            onChange={handleChange}
          />
        </div>

        <button onClick={onReset} className="btn-cancel">Reset</button>
      </div>
    </div>
  );
}

export default FilterBar;
