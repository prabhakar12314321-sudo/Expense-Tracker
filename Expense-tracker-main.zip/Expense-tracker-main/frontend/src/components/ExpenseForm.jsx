import { useState, useEffect } from "react";

function ExpenseForm({ categories, onSubmit, existingData, onCancel }) {
  const [form, setForm] = useState({
    title: "",
    amount: "",
    category_id: "",
    expense_date: new Date().toISOString().split("T")[0],
    description: "",
  });

  const [error, setError] = useState("");

  // If editing, prefill the form
  useEffect(() => {
    if (existingData) {
      setForm({
        title: existingData.TITLE || "",
        amount: existingData.AMOUNT || "",
        category_id: existingData.CATEGORY_ID || "",
        expense_date: existingData.EXPENSE_DATE || new Date().toISOString().split("T")[0],
        description: existingData.DESCRIPTION || "",
      });
    }
  }, [existingData]);

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  function handleSubmit(e) {
    e.preventDefault();
    setError("");

    if (!form.title.trim()) {
      setError("Title is required");
      return;
    }
    if (!form.amount || isNaN(form.amount) || Number(form.amount) <= 0) {
      setError("Enter a valid positive amount");
      return;
    }

    onSubmit(form);
  }

  return (
    <form onSubmit={handleSubmit} className="expense-form">
      <h2>{existingData ? "Edit Expense" : "Add New Expense"}</h2>

      {error && <p className="error">{error}</p>}

      <div className="form-group">
        <label>Title *</label>
        <input
          type="text"
          name="title"
          value={form.title}
          onChange={handleChange}
          placeholder="e.g. Lunch, Bus ticket"
        />
      </div>

      <div className="form-group">
        <label>Amount (₹) *</label>
        <input
          type="number"
          name="amount"
          value={form.amount}
          onChange={handleChange}
          placeholder="e.g. 250"
          min="1"
        />
      </div>

      <div className="form-group">
        <label>Category</label>
        <select name="category_id" value={form.category_id} onChange={handleChange}>
          <option value="">-- Select Category --</option>
          {categories.map((cat) => (
            <option key={cat.ID} value={cat.ID}>
              {cat.NAME}
            </option>
          ))}
        </select>
      </div>

      <div className="form-group">
        <label>Date</label>
        <input
          type="date"
          name="expense_date"
          value={form.expense_date}
          onChange={handleChange}
        />
      </div>

      <div className="form-group">
        <label>Description</label>
        <input
          type="text"
          name="description"
          value={form.description}
          onChange={handleChange}
          placeholder="Optional note"
        />
      </div>

      <div className="form-actions">
        <button type="submit">{existingData ? "Update" : "Add Expense"}</button>
        {onCancel && (
          <button type="button" onClick={onCancel} className="btn-cancel">
            Cancel
          </button>
        )}
      </div>
    </form>
  );
}

export default ExpenseForm;
