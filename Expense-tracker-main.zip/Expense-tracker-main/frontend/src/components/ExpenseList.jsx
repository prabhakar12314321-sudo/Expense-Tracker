function ExpenseList({ expenses, onEdit, onDelete }) {
  if (expenses.length === 0) {
    return <p className="empty-msg">No expenses found. Add one above!</p>;
  }

  return (
    <table className="expense-table">
      <thead>
        <tr>
          <th>Title</th>
          <th>Amount</th>
          <th>Category</th>
          <th>Date</th>
          <th>Description</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {expenses.map((exp) => (
          <tr key={exp.ID}>
            <td>{exp.TITLE}</td>
            <td>₹{Number(exp.AMOUNT).toFixed(2)}</td>
            <td>{exp.CATEGORY || "—"}</td>
            <td>{exp.EXPENSE_DATE}</td>
            <td>{exp.DESCRIPTION || "—"}</td>
            <td>
              <button onClick={() => onEdit(exp)} className="btn-edit">Edit</button>
              <button onClick={() => onDelete(exp.ID)} className="btn-delete">Delete</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export default ExpenseList;
