# Expense Tracker — Full Stack Web Application

A full-stack expense management application built with **React.js**, **Node.js**, **Express.js**, and **Oracle SQL**.

## Features

- Add, edit, and delete expenses
- Filter by category and date range
- Category-based expense tracking
- Total amount summary
- Input validation on both frontend and backend
- RESTful API architecture

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React.js, Vite |
| Backend | Node.js, Express.js |
| Database | Oracle SQL (11g XE or higher) |
| API Testing | Postman |

## Project Structure

```
expense-tracker/
├── backend/
│   ├── db/
│   │   ├── connection.js      # Oracle DB connection
│   │   └── schema.sql         # Table creation + seed data
│   ├── routes/
│   │   ├── expenses.js        # 5 expense APIs
│   │   └── categories.js      # Category API
│   ├── server.js              # Express entry point
│   └── package.json
└── frontend/
    ├── src/
    │   ├── components/
    │   │   ├── ExpenseForm.jsx
    │   │   ├── ExpenseList.jsx
    │   │   └── FilterBar.jsx
    │   ├── App.jsx
    │   ├── App.css
    │   ├── api.js             # All fetch calls
    │   └── main.jsx
    ├── index.html
    ├── vite.config.js
    └── package.json
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/expenses` | Get all expenses (supports `?category_id`, `?from_date`, `?to_date`) |
| GET | `/api/expenses/:id` | Get single expense by ID |
| POST | `/api/expenses` | Add new expense |
| PUT | `/api/expenses/:id` | Update existing expense |
| DELETE | `/api/expenses/:id` | Delete an expense |
| GET | `/api/expenses/summary/by-category` | Category-wise total |
| GET | `/api/categories` | Get all categories |

## Setup Instructions

### Prerequisites

- Node.js (v18+)
- Oracle Database (XE 11g or 21c)
- Oracle Instant Client (for `oracledb` npm package)

### 1. Database Setup

Open Oracle SQL Developer or SQLPlus and run:

```sql
-- Run backend/db/schema.sql
```

This creates the `categories` and `expenses` tables and inserts default categories.

### 2. Backend Setup

```bash
cd backend
npm install
```

Open `db/connection.js` and update your credentials:

```js
const dbConfig = {
  user: "your_username",
  password: "your_password",
  connectString: "localhost/XE",
};
```

Then start the server:

```bash
node server.js
# Server running on http://localhost:5000
```

### 3. Frontend Setup

```bash
cd frontend
npm install
npm run dev
# App running on http://localhost:5173
```

### 4. Test APIs with Postman

Example POST request to add an expense:

```
POST http://localhost:5000/api/expenses
Content-Type: application/json

{
  "title": "Lunch",
  "amount": 150,
  "category_id": 1,
  "expense_date": "2025-05-24",
  "description": "Canteen food"
}
```

## Screenshots

> Add screenshots after running the app locally.
