const express = require("express");
const cors = require("cors");

const expenseRoutes = require("./routes/expenses");
const categoryRoutes = require("./routes/categories");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// Routes
app.use("/api/expenses", expenseRoutes);
app.use("/api/categories", categoryRoutes);

// Health check
app.get("/", (req, res) => {
  res.send("Expense Tracker API is running");
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
