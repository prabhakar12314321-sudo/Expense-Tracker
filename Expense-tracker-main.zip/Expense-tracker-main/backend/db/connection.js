const oracledb = require("oracledb");

// Change these to match your Oracle setup
const dbConfig = {
  user: "system",
  password: "Ujjawal2004",
  connectString: "localhost/XE",
};
async function getConnection() {
  const connection = await oracledb.getConnection(dbConfig);
  return connection;
}

module.exports = { getConnection };
