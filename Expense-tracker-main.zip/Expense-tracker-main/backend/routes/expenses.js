const express = require("express");
const oracledb = require("oracledb");
const router = express.Router();
const { getConnection } = require("../db/connection");

// API 1 — GET all expenses (supports filtering by category and date)
router.get("/", async (req, res) => {
  let conn;
  try {
    conn = await getConnection();

    const { category_id, from_date, to_date } = req.query;

    let query = `
      SELECT e.id, e.title, e.amount, e.description,
             TO_CHAR(e.expense_date, 'YYYY-MM-DD') AS expense_date,
             c.name AS category
      FROM expenses e
      LEFT JOIN categories c ON e.category_id = c.id
      WHERE 1=1
    `;
    const binds = {};

    if (category_id) {
      query += " AND e.category_id = :category_id";
      binds.category_id = Number(category_id);
    }
    if (from_date) {
      query += " AND e.expense_date >= TO_DATE(:from_date, 'YYYY-MM-DD')";
      binds.from_date = from_date;
    }
    if (to_date) {
      query += " AND e.expense_date <= TO_DATE(:to_date, 'YYYY-MM-DD')";
      binds.to_date = to_date;
    }

    query += " ORDER BY e.expense_date DESC";

    const result = await conn.execute(query, binds, { outFormat: oracledb.OUT_FORMAT_OBJECT });
    res.json(result.rows);
  } catch (err) {
    console.error("Error fetching expenses:", err.message);
    res.status(500).json({ error: "Failed to fetch expenses" });
  } finally {
    if (conn) await conn.close();
  }
});

// API 2 — GET a single expense by ID
router.get("/:id", async (req, res) => {
  let conn;
  try {
    conn = await getConnection();

    const result = await conn.execute(
      `SELECT e.id, e.title, e.amount, e.description,
              TO_CHAR(e.expense_date, 'YYYY-MM-DD') AS expense_date,
              c.name AS category
       FROM expenses e
       LEFT JOIN categories c ON e.category_id = c.id
       WHERE e.id = :id`,
      { id: Number(req.params.id) },
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Expense not found" });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error("Error fetching expense:", err.message);
    res.status(500).json({ error: "Failed to fetch expense" });
  } finally {
    if (conn) await conn.close();
  }
});

// API 3 — POST add a new expense
router.post("/", async (req, res) => {
  let conn;
  try {
    const { title, amount, category_id, expense_date, description } = req.body;

    if (!title || !title.trim()) {
      return res.status(400).json({ error: "Title is required" });
    }
    if (!amount || isNaN(amount) || Number(amount) <= 0) {
      return res.status(400).json({ error: "Amount must be a positive number" });
    }

    conn = await getConnection();

    await conn.execute(
      `INSERT INTO expenses (id, title, amount, category_id, expense_date, description)
       VALUES (expenses_seq.NEXTVAL, :title, :amount, :category_id, TO_DATE(:expense_date, 'YYYY-MM-DD'), :description)`,
      {
        title: title.trim(),
        amount: Number(amount),
        category_id: category_id ? Number(category_id) : null,
        expense_date: expense_date || new Date().toISOString().split("T")[0],
        description: description || null,
      },
      { autoCommit: true }
    );

    res.status(201).json({ message: "Expense added successfully" });
  } catch (err) {
    console.error("Error adding expense:", err.message);
    res.status(500).json({ error: "Failed to add expense" });
  } finally {
    if (conn) await conn.close();
  }
});

// API 4 — PUT update an existing expense
router.put("/:id", async (req, res) => {
  let conn;
  try {
    const { title, amount, category_id, expense_date, description } = req.body;

    if (!title || !title.trim()) {
      return res.status(400).json({ error: "Title is required" });
    }
    if (!amount || isNaN(amount) || Number(amount) <= 0) {
      return res.status(400).json({ error: "Amount must be a positive number" });
    }

    conn = await getConnection();

    const result = await conn.execute(
      `UPDATE expenses
       SET title = :title, amount = :amount, category_id = :category_id,
           expense_date = TO_DATE(:expense_date, 'YYYY-MM-DD'), description = :description
       WHERE id = :id`,
      {
        title: title.trim(),
        amount: Number(amount),
        category_id: category_id ? Number(category_id) : null,
        expense_date: expense_date || new Date().toISOString().split("T")[0],
        description: description || null,
        id: Number(req.params.id),
      },
      { autoCommit: true }
    );

    if (result.rowsAffected === 0) {
      return res.status(404).json({ error: "Expense not found" });
    }

    res.json({ message: "Expense updated successfully" });
  } catch (err) {
    console.error("Error updating expense:", err.message);
    res.status(500).json({ error: "Failed to update expense" });
  } finally {
    if (conn) await conn.close();
  }
});

// API 5 — DELETE an expense
router.delete("/:id", async (req, res) => {
  let conn;
  try {
    conn = await getConnection();

    const result = await conn.execute(
      `DELETE FROM expenses WHERE id = :id`,
      { id: Number(req.params.id) },
      { autoCommit: true }
    );

    if (result.rowsAffected === 0) {
      return res.status(404).json({ error: "Expense not found" });
    }

    res.json({ message: "Expense deleted successfully" });
  } catch (err) {
    console.error("Error deleting expense:", err.message);
    res.status(500).json({ error: "Failed to delete expense" });
  } finally {
    if (conn) await conn.close();
  }
});

// Bonus — GET expenses grouped by category
router.get("/summary/by-category", async (req, res) => {
  let conn;
  try {
    conn = await getConnection();

    const result = await conn.execute(
      `SELECT c.name AS category, COUNT(e.id) AS total_count, SUM(e.amount) AS total_amount
       FROM expenses e
       LEFT JOIN categories c ON e.category_id = c.id
       GROUP BY c.name
       ORDER BY total_amount DESC`,
      {},
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    );

    res.json(result.rows);
  } catch (err) {
    console.error("Error fetching summary:", err.message);
    res.status(500).json({ error: "Failed to fetch summary" });
  } finally {
    if (conn) await conn.close();
  }
});

module.exports = router;